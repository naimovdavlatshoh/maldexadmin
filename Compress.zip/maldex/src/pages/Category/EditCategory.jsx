import React from 'react'

const EditCategory = () => {
  return (
    <div>EditCategory</div>
  )
}

export default EditCategory