import { Route, Routes } from "react-router-dom";
import AllCategories from "./pages/Category/AllCategories";
import CreateCategory from "./pages/Category/CreateCategory";
import EditCategory from "./pages/Category/EditCategory";
import CategoryDetails from "./pages/Category/CategoryDetails";
import Main from "./pages/Main";

function App() {
    return (
        <Routes>
            <Route path="/" element={<Main />} />
            <Route path="/categories" element={<AllCategories />} />
            <Route path="/create-category" element={<CreateCategory />} />
            <Route path="/edit-category" element={<EditCategory />} />
            <Route path="/category/:id" element={<CategoryDetails />} />
        </Routes>
    );
}

export default App;
